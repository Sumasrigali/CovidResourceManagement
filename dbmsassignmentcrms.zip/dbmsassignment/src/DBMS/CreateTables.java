package DBMS;
//import java.io.*;
import java.sql.*;
public class CreateTables 
{ 
	public static void main(String[] args)throws Exception
	{
		Class.forName("oracle.jdbc.OracleDriver");
		Connection con=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","19737116itb","sumasri");
		Statement st=con.createStatement();
		
		//Queries for creating tables
		
		String sql="create table login(Loginid number(5),Login_username varchar2(20),password varchar2(30))";
		
		
		
		
		st.executeUpdate(sql);
		System.out.println("Table created successfully");
		con.close();
	}
}