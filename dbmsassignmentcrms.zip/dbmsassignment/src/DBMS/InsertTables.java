package DBMS;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
//1602-19-737-116 Suma Sri
@SuppressWarnings("serial")
public class InsertTables extends Frame implements ActionListener 
{
	MenuBar mb;
	MenuItem m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16,m17;
	Menu patient,donor,ICUbeds,remedesivirs,plasma;
	Button insertButton,submit;
	
	TextField patidText, patNameText, patMailText, patMobilenoText,patAddressText;
	TextField donoridText, donorNameText, donorMobilenoText, donorBloodgrpText, donorAddressText;
	TextField bedidText, HospitalNameText, placeText, bedtypeText;
	TextField remidText, availableRemText, remPlaceText;
	TextField plasmaidText,plasmagrpText,plasmaplaceText;
	TextArea errorText;
	Connection connection;
	Statement statement;
	
	//For updates
		Button modify;
		List patientList, donorList, ICUbedsList, remedesivirsList, plasmaList;
		
		ResultSet rs;
		//For delete
		Button deleteRowButton;
		
		public InsertTables()
		{
			try 
			{
				Class.forName ("oracle.jdbc.driver.OracleDriver");
			} 
			catch (Exception e) 
			{
				System.err.println("Unable to find and load driver");
				System.exit(1);
			}
			connectToDB ();
		}

		public void connectToDB() 
	    {
			try 
			{
			  connection=DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","19737116itb","sumasri");
			  statement = connection.createStatement();

			} 
			catch (SQLException connectException) 
			{
			  System.out.println(connectException.getMessage());
			  System.out.println(connectException.getSQLState());
			  System.out.println(connectException.getErrorCode());
			  System.exit(1);
			}
	    }
		
		public void buildFrame()
		{
			//Basic Frame Properties
			setTitle("Covid Resource Management System");
			setSize(500, 600);
			setVisible(true);
			
			//menubar
			mb = new MenuBar();
			setMenuBar(mb);  
	        setSize(550,500);  
	        setLayout(null);  
	        setVisible(true);
	        
	        //Patient 
	         patient=new Menu("Patient");  
	        
	         m1=new MenuItem("Insert Patient");  
	         m2=new MenuItem("Update Patient");  
	         m3=new MenuItem("Delete Patient");  
	         m4=new MenuItem("View Patient");
	           
	        patient.add(m1);  
	        patient.add(m2);  
	        patient.add(m3); 
	        patient.add(m4);
	        
	        mb.add(patient);
	        
	      //Donor
	        donor=new Menu("Donor"); 
	        m5=new MenuItem("Insert Donor");
	        m6=new MenuItem("Update Donor");
	        m7=new MenuItem("Delete Donor");
	        m8=new MenuItem("View Donor");
	        
	        donor.add(m5);
	        donor.add(m6);
	        donor.add(m7);
	        donor.add(m8);
	        
	        mb.add(donor);
	        
	      //ICUbeds
	        ICUbeds=new Menu("ICUbeds");  
	        m9=new MenuItem("Insert ICUbeds");
	        m10=new MenuItem("Delete ICUbeds");
	        m11=new MenuItem("View ICUbeds");
	       
	        ICUbeds.add(m9);
	        ICUbeds.add(m10);
	        ICUbeds.add(m11);
	        
	        mb.add(ICUbeds);
	        
	        //Remedesivirs
	        remedesivirs=new Menu("Remedesivirs");  
	        m12=new MenuItem("Insert Remedesivirs");
	        m13=new MenuItem("Delete Remedesivirs");
	        m14=new MenuItem("View Remedesivirs");
	       
	        remedesivirs.add(m12);
	        remedesivirs.add(m13);
	        remedesivirs.add(m14);
	        
	        mb.add(remedesivirs);
	        
	        //Plasma
	        plasma=new Menu("Plasma");  
	        m15=new MenuItem("Insert Plasma");
	        m16=new MenuItem("Delete Plasma");
	        m17=new MenuItem("View Plasma");
	       
	        plasma.add(m15);
	        plasma.add(m16);
	        plasma.add(m17);
	        
	        mb.add(plasma);
	        
	      //Registering action Listeners
	        m1.addActionListener(this);
	        m2.addActionListener(this);
	        m3.addActionListener(this);
	        m4.addActionListener(this);
	        m5.addActionListener(this);
	        m6.addActionListener(this);
	        m7.addActionListener(this);
	        m8.addActionListener(this);
	        m9.addActionListener(this);
	        m10.addActionListener(this);
	        m11.addActionListener(this);
	        m12.addActionListener(this);
	        m13.addActionListener(this);
	        m14.addActionListener(this);
	        m15.addActionListener(this);
	        m16.addActionListener(this);
	        m17.addActionListener(this);
	        
	        			
		}
		public void actionPerformed(ActionEvent ae)
		{
			String arg = ae.getActionCommand();
			if(arg.equals("Insert Patient"))
				this.buildGUIPatient();
			if(arg.equals("Update Patient"))
				this.updatePatientGUI();
			if(arg.equals("Delete Patient"))
				this.deleteGUIPatient();
			if(arg.equals("View Patient"))
				this.viewPatientGUI();
			if(arg.equals("Insert Donor"))
				this.buildGUIDonor();
			if(arg.equals("Update Donor"))
				this.updateDonorGUI();
			if(arg.equals("Delete Donor"))
				this.deleteGUIDonor();
			if(arg.equals("View Donor"))
				this.viewDonorGUI();	
			if(arg.equals("Insert ICUbeds"))
				this.buildGUIICUbeds();
			if(arg.equals("Delete ICUbeds"))
				this.deleteGUIICUbeds();
			if(arg.equals("View ICUbeds"))
				this.viewICUbedsGUI();
			if(arg.equals("Insert Remedesivirs"))
				this.buildRemedesivirsGUI();
			if(arg.equals("Delete Remedesivirs"))
				this.deleteGUIRemedesivirs();
			if(arg.equals("View Remedesivirs"))
				this.viewRemedesivirsGUI();
			if(arg.equals("Insert Plasma"))
				this.buildGUIPlasma();
			if(arg.equals("Delete Plasma"))
				this.deleteGUIPlasma();
			if(arg.equals("View Plasma"))
				this.viewPlasmaGUI();
		}
		
		public void buildGUIPatient() 
		{	
			removeAll();
			//Handle Insert Account Button
			insertButton = new Button("Submit");
			insertButton.addActionListener(new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{		  
					  String query= "INSERT INTO patient VALUES('" + patidText.getText()+ "','"+ patNameText.getText() +"','"+ patMailText.getText() +"','" + patMobilenoText.getText() + "','" + patAddressText.getText() + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
					} 
					catch (SQLException insertException) 
					{
					  displaySQLErrors(insertException);
					}
				}
			});	
		    patidText = new TextField(15);
			patNameText = new TextField(15);
			patMailText = new TextField(15);
			patMobilenoText= new TextField(15);
			patAddressText= new TextField(15);

			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Patient ID:"));
			first.add(patidText);
			first.add(new Label("Patient Name:"));
			first.add(patNameText);
			first.add(new Label("Patient Email:"));
			first.add(patMailText);
			first.add(new Label("Patient Mobileno:"));
			first.add(patMobilenoText);
			first.add(new Label("Patient Address:"));
			first.add(patAddressText);
			first.setBounds(125,90,200,100);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(insertButton);
	        		second.setBounds(125,220,150,100);         
			
			Panel third = new Panel();
			third.add(errorText);
			third.setBounds(125,320,300,200);
			
			//setLayout(null);

			add(first);
			add(second);
			add(third);
			
			setLayout(new FlowLayout());
			setVisible(true);
		    
		}
		
		public void buildGUIDonor() 
		{	 	
			removeAll();
			//Handle Insert Account Button
			insertButton = new Button("Submit");
			insertButton.addActionListener(new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{		  
						String query= "INSERT INTO donor VALUES('" + donoridText.getText()+ "','"+ donorNameText.getText() +"','"+ donorMobilenoText.getText() +"','" + donorBloodgrpText.getText() + "','" + donorAddressText.getText() + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
					} 
					catch (SQLException insertException) 
					{
					  displaySQLErrors(insertException);
					}
				}
			});	
			donoridText = new TextField(15);
			donorNameText = new TextField(15);
			donorMobilenoText = new TextField(15);
			donorBloodgrpText= new TextField(15);
			donorAddressText= new TextField(15);
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Donor ID:"));
			first.add(donoridText);
			first.add(new Label("Donor Name:"));
			first.add(donorNameText);
			first.add(new Label("Donor Mobileno:"));
			first.add(donorMobilenoText);
			first.add(new Label("Donor Bloodgrp:"));
			first.add(donorBloodgrpText);
			first.add(new Label("Donor Address:"));
			first.add(donorAddressText);
			
			first.setBounds(125,90,200,100);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(insertButton);
	        		second.setBounds(125,220,150,100);         
			
			Panel third = new Panel();
			third.add(errorText);
			third.setBounds(125,320,300,200);
			
			//setLayout(null);

			add(first);
			add(second);
			add(third);
			
			setLayout(new FlowLayout());
			setVisible(true);
		    
		
		}
		
		
		public void buildGUIICUbeds() 
		{	 	
			removeAll();
			//Handle Insert Account Button
			insertButton = new Button("Submit");
			insertButton.addActionListener(new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{		  
						String query= "INSERT INTO ICUbeds VALUES('" + bedidText.getText()+ "','"+ HospitalNameText.getText() +"','" + placeText.getText() + "','" + bedtypeText.getText() + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
					} 
					catch (SQLException insertException) 
					{
					  displaySQLErrors(insertException);
					}
				}
			});	
			bedidText = new TextField(15);
			HospitalNameText = new TextField(15);
			placeText = new TextField(15);
			bedtypeText= new TextField(15);
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(4, 2));
			first.add(new Label("Bed ID:"));
			first.add(bedidText);
			first.add(new Label("Hospital Name:"));
			first.add(HospitalNameText);
			first.add(new Label("Place:"));
			first.add(placeText);
			first.add(new Label("Bed Type:"));
			first.add(bedtypeText);
			
			first.setBounds(125,90,200,100);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(insertButton);
	        		second.setBounds(125,220,150,100);         
			
			Panel third = new Panel();
			third.add(errorText);
			third.setBounds(125,320,300,200);
			
			//setLayout(null);

			add(first);
			add(second);
			add(third);
			
			setLayout(new FlowLayout());
			setVisible(true);
		    
		
		}
		
		public void buildRemedesivirsGUI() 
		{	
			removeAll();
			//Handle Insert Account Button
			insertButton = new Button("Submit");
			insertButton.addActionListener(new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{		  
					  String query= "INSERT INTO remedesivirs VALUES('" + remidText.getText()+ "','"+ availableRemText.getText()+ "','"  + remPlaceText.getText() + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
					} 
					catch (SQLException insertException) 
					{
					  displaySQLErrors(insertException);
					}
				}
			});	
		    remidText = new TextField(15);
			availableRemText = new TextField(15);
			remPlaceText = new TextField(15);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Remedesivir ID:"));
			first.add(remidText);
			first.add(new Label("Available Remedesivirs:"));
			first.add(availableRemText);
			first.add(new Label("Remedesivir Place:"));
			first.add(remPlaceText);
			first.setBounds(125,90,200,100);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(insertButton);
	        		second.setBounds(125,220,150,100);         
			
			Panel third = new Panel();
			third.add(errorText);
			third.setBounds(125,320,300,200);
			
			//setLayout(null);

			add(first);
			add(second);
			add(third);
			
			setLayout(new FlowLayout());
			setVisible(true);
		    
		}
		
		public void buildGUIPlasma() 
		{	
			removeAll();
			//Handle Insert Account Button
			insertButton = new Button("Submit");
			insertButton.addActionListener(new ActionListener() 
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{		  
					  String query= "INSERT INTO plasma VALUES('" + plasmaidText.getText()+ "','"+ plasmagrpText.getText() +"','" + plasmaplaceText.getText() + "')";
					  int i = statement.executeUpdate(query);
					  errorText.append("\nInserted " + i + " rows successfully");
					} 
					catch (SQLException insertException) 
					{
					  displaySQLErrors(insertException);
					}
				}
			});	
		    plasmaidText = new TextField(15);
			plasmagrpText = new TextField(15);
			plasmaplaceText = new TextField(15);

			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Plasma ID:"));
			first.add(plasmaidText);
			first.add(new Label("Plasma/Blood Group:"));
			first.add(plasmagrpText);
			first.add(new Label("Plasma Place:"));
			first.add(plasmaplaceText);
			first.setBounds(125,90,200,100);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(insertButton);
	        second.setBounds(125,220,150,100);         
			
			Panel third = new Panel();
			third.add(errorText);
			third.setBounds(125,320,300,200);
			
			//setLayout(null);

			add(first);
			add(second);
			add(third);
			
			setLayout(new FlowLayout());
			setVisible(true);
		    
		}
		
		
		
		
		
		private void loadPatient() 
		{	   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM patient");
			  while (rs.next()) 
			  {
				  patientList.add(rs.getString("patid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}
		}
		
		
		public void updatePatientGUI() 
		{	
			removeAll();
			patientList = new List(6);
			loadPatient();
			add(patientList);
			
			//When a list item is selected populate the text fields
			patientList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM patient");
						while (rs.next()) 
						{
							if (rs.getString("patid").equals(patientList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							patidText.setText(rs.getString("patid"));
							patNameText.setText(rs.getString("patName"));
							patMailText.setText(rs.getString("patMail"));
							patMobilenoText.setText(rs.getString("patMobileno"));
							patAddressText.setText(rs.getString("patAddress"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			//Handle Update Menu Button
			modify = new Button("Modify");
			modify.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("UPDATE patient  SET patid='" + patidText.getText() + "',patMail='" + patMailText.getText() + "',patMobileno='" + patMobilenoText.getText() + "',patAddress='" + patAddressText.getText()+ "' WHERE patid = '" + patientList.getSelectedItem() + "' ");
						errorText.append("\nUpdated " + i + " rows successfully");
						patientList.removeAll();
						loadPatient();
					} 
					catch (SQLException insertException) 
					{
						displaySQLErrors(insertException);
					}
				}
			});
			
			patidText = new TextField(15);
			patNameText = new TextField(15);
			patNameText.setEditable(false);
			patMailText=new TextField(15);
			patMobilenoText = new TextField(15);
			patAddressText = new TextField(15);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Patient ID:"));
			first.add(patidText);
			first.add(new Label("Patient Name:"));
			first.add(patNameText);
			first.add(new Label("Patient Email:"));
			first.add(patMailText);
			first.add(new Label("Patient Mobileno:"));
			first.add(patMobilenoText);
			first.add(new Label("Patient Address:"));
			first.add(patAddressText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			
			add(second);
			add(third);
		    
			//setTitle("Update ....");
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void deleteGUIPatient () 
		{	
			removeAll();
		    patientList = new List(10);
			loadPatient();
			add(patientList);
			
			//When a list item is selected populate the text fields
			patientList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM patient");
						while (rs.next()) 
						{
							if (rs.getString("patid").equals(patientList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							patidText.setText(rs.getString("patid"));
							patNameText.setText(rs.getString("patName"));
							patMailText.setText(rs.getString("patMail"));
							patMobilenoText.setText(rs.getString("patMobileno"));
							patAddressText.setText(rs.getString("patAddress"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete menu Button
			deleteRowButton = new Button("Delete Row");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM patient WHERE patid = '" + patientList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						patidText.setText(null);
						patNameText.setText(null);
						patMailText.setText(null);
						patMobilenoText.setText(null);
						patAddressText.setText(null);
						patientList.removeAll();
						loadPatient();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			patidText = new TextField(15);
			patNameText = new TextField(15);
			patMailText = new TextField(15);
			patMobilenoText = new TextField(15);
			patAddressText = new TextField(15);
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);
			
			patidText.setEditable(false);
			patNameText.setEditable(false);
			patMailText.setEditable(false);
			patMobilenoText.setEditable(false);
			patAddressText.setEditable(false);
		

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Patient ID:"));
			first.add(patidText);
			first.add(new Label("Patient Name:"));
			first.add(patNameText);
			first.add(new Label("Patient Email:"));
			first.add(patMailText);
			first.add(new Label("Patient Mobileno:"));
			first.add(patMobilenoText);
			first.add(new Label("Patient Address:"));
			first.add(patAddressText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    

			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		private void loadDonor() 
		{	   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM donor");
			  while (rs.next()) 
			  {
				  donorList.add(rs.getString("donorid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}
		}
		public void updateDonorGUI() 
		{	
			removeAll();
			donorList = new List(6);
			loadDonor();
			add(donorList);
			
			//When a list item is selected populate the text fields
			donorList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM donor");
						while (rs.next()) 
						{
							if (rs.getString("donorid").equals(donorList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							donoridText.setText(rs.getString("donorid"));
							donorNameText.setText(rs.getString("donorName"));
							donorMobilenoText.setText(rs.getString("donorMobileno"));
							donorBloodgrpText.setText(rs.getString("donorBloodgrp"));
							donorAddressText.setText(rs.getString("donorAddress"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			//Handle Update Menu Button
			modify = new Button("Update Donor");
			modify.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("UPDATE donor  SET donorid='" + donoridText.getText() + "',donorMobileno='" + donorMobilenoText.getText() + "',donorAddress='" + donorAddressText.getText()+ "' WHERE donorid = '" + donorList.getSelectedItem() + "' ");
						errorText.append("\nUpdated " + i + " rows successfully");
						donorList.removeAll();
						loadDonor();
					} 
					catch (SQLException insertException) 
					{
						displaySQLErrors(insertException);
					}
				}
			});
			
			donoridText = new TextField(15);
			donorNameText = new TextField(15);
			donorNameText.setEditable(false);
			donorMobilenoText = new TextField(15);
			donorBloodgrpText = new TextField(15);
			donorBloodgrpText.setEditable(false);
			donorAddressText = new TextField(15);
			
			

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Donor ID:"));
			first.add(donoridText);
			first.add(new Label("Donor Name:"));
			first.add(donorNameText);
			first.add(new Label("Donor Mobileno:"));
			first.add(donorMobilenoText);
			first.add(new Label("Donor Bloodgrp:"));
			first.add(donorBloodgrpText);
			first.add(new Label("Donor Address:"));
			first.add(donorAddressText);
			
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    
			
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void deleteGUIDonor()
		{
			removeAll();
		    donorList = new List(10);
			loadDonor();
			add(donorList);
			
			//When a list item is selected populate the text fields
			donorList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM donor");
						while (rs.next()) 
						{
							if (rs.getString("donorid").equals(donorList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							donoridText.setText(rs.getString("donorid"));
							donorNameText.setText(rs.getString("donorName"));
							donorMobilenoText.setText(rs.getString("donorMobileno"));
							donorBloodgrpText.setText(rs.getString("donorBloodgrp"));
							donorAddressText.setText(rs.getString("donorAddress"));
							
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete donor Button
			deleteRowButton = new Button("Delete Row");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM donor WHERE donorid = '" + donorList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						donoridText.setText(null);
						donorNameText.setText(null);
						donorMobilenoText.setText(null);
						donorBloodgrpText.setText(null);
						donorAddressText.setText(null);
						donorList.removeAll();
						loadDonor();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			donoridText = new TextField(15);
			donorNameText = new TextField(15);
			donorMobilenoText = new TextField(15);
			donorBloodgrpText = new TextField(15);
			donorAddressText = new TextField(15);
			
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);
			
			donoridText.setEditable(false);
			donorNameText.setEditable(false);
			donorMobilenoText.setEditable(false);
			donorBloodgrpText.setEditable(false);
			donorAddressText.setEditable(false);
			
		    

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Donor ID:"));
			first.add(donoridText);
			first.add(new Label("Donor Name:"));
			first.add(donorNameText);
			first.add(new Label("Donor Mobileno:"));
			first.add(donorMobilenoText);
			first.add(new Label("Donor Bloodgrp:"));
			first.add(donorBloodgrpText);
			first.add(new Label("Donor Address:"));
			first.add(donorAddressText);
			
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    

			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		private void loadICUbeds() 
		{	   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM ICUbeds");
			  while (rs.next()) 
			  {
				  ICUbedsList.add(rs.getString("bedid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}
		}
		
		
		public void deleteGUIICUbeds()
		{
			removeAll();
		    ICUbedsList = new List(10);
			loadICUbeds();
			add(ICUbedsList);
			
			//When a list item is selected populate the text fields
			ICUbedsList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM ICUbeds");
						while (rs.next()) 
						{
							if (rs.getString("bedid").equals(ICUbedsList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							bedidText.setText(rs.getString("bedid"));
							HospitalNameText.setText(rs.getString("HospitalName"));
						    placeText.setText(rs.getString("place"));
							bedtypeText.setText(rs.getString("bedtype"));
							
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete ICUbeds Button
			deleteRowButton = new Button("Delete Row");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM ICUbeds WHERE bedid = '" + ICUbedsList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						bedidText.setText(null);
						HospitalNameText.setText(null);
						placeText.setText(null);
						bedtypeText.setText(null);
						ICUbedsList.removeAll();
						loadICUbeds();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			bedidText = new TextField(15);
			HospitalNameText = new TextField(15);
			placeText = new TextField(15);
			bedtypeText = new TextField(15);		
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);
			
			bedidText.setEditable(false);
			HospitalNameText.setEditable(false);
			placeText.setEditable(false);
			bedtypeText.setEditable(false);
		    

			Panel first = new Panel();
			first.setLayout(new GridLayout(4, 2));
			first.add(new Label("Bed id:"));
			first.add(bedidText);
			first.add(new Label("Hospital Name:"));
			first.add(HospitalNameText);
			first.add(new Label("Place:"));
			first.add(placeText);
			first.add(new Label("Bed Type:"));
			first.add(bedtypeText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    

			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		private void loadRemedesivirs() 
		{	   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM remedesivirs");
			  while (rs.next()) 
			  {
				  remedesivirsList.add(rs.getString("remid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}
		}
		
		public void deleteGUIRemedesivirs () 
		{	
			removeAll();
		    remedesivirsList = new List(10);
			loadRemedesivirs();
			add(remedesivirsList);
			
			//When a list item is selected populate the text fields
			remedesivirsList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM remedesivirs");
						while (rs.next()) 
						{
							if (rs.getString("remid").equals(remedesivirsList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							remidText.setText(rs.getString("remid"));
							availableRemText.setText(rs.getString("availableRem"));
							remPlaceText.setText(rs.getString("remPlace"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete remedesivirs Button
			deleteRowButton = new Button("Delete Row");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM remedesivirs WHERE remid = '" + remedesivirsList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						remidText.setText(null);
						availableRemText.setText(null);
						remPlaceText.setText(null);
						remedesivirsList.removeAll();
						loadRemedesivirs();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			remidText = new TextField(15);
			availableRemText = new TextField(15);
			remPlaceText = new TextField(15);
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);
			
			remidText.setEditable(false);
			availableRemText.setEditable(false);
			remPlaceText.setEditable(false);
		

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Remedesivir ID:"));
			first.add(remidText);
			first.add(new Label("Available Remedesivirs:"));
			first.add(availableRemText);
			first.add(new Label("Remedesivir Place:"));
			first.add(remPlaceText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    

			setLayout(new FlowLayout());
			setVisible(true);
			
		} 
		
		
		private void loadPlasma() 
		{	   
			try 
			{
			  rs = statement.executeQuery("SELECT * FROM plasma");
			  while (rs.next()) 
			  {
				  plasmaList.add(rs.getString("plasmaid"));
			  }
			} 
			catch (SQLException e) 
			{ 
			  displaySQLErrors(e);
			}
		} 
		public void deleteGUIPlasma () 
		{	
			removeAll();
		    plasmaList = new List(10);
			loadPlasma();
			add(plasmaList);
			
			//When a list item is selected populate the text fields
			plasmaList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM plasma");
						while (rs.next()) 
						{
							if (rs.getString("plasmaid").equals(plasmaList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							plasmaidText.setText(rs.getString("plasmaid"));
							plasmagrpText.setText(rs.getString("plasmagrp"));
							plasmaplaceText.setText(rs.getString("plasmaplace"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});
		    
			//Handle Delete plasma Button
			deleteRowButton = new Button("Delete Row");
			deleteRowButton.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("DELETE FROM plasma WHERE plasmaid = '" + plasmaList.getSelectedItem()+"'");
						errorText.append("\nDeleted " + i + " rows successfully");
						plasmaidText.setText(null);
						plasmagrpText.setText(null);
						plasmaplaceText.setText(null);
						plasmaList.removeAll();
						loadPlasma();
					} 
					catch (SQLException deleteException) 
					{
						displaySQLErrors(deleteException);
					}
				}
			});
			
			plasmaidText = new TextField(15);
			plasmagrpText = new TextField(15);
			plasmaplaceText = new TextField(15);
			
			errorText = new TextArea(10, 40);
			errorText.setEditable(false);
			
			plasmaidText.setEditable(false);
			plasmagrpText.setEditable(false);
			plasmaplaceText.setEditable(false);
		

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Plasma ID:"));
			first.add(plasmaidText);
			first.add(new Label("Plasma/Blood Group:"));
			first.add(plasmagrpText);
			first.add(new Label("Plasma Place:"));
			first.add(plasmaplaceText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			second.add(deleteRowButton);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    

			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void viewPatientGUI() 
		{	
			removeAll();
			patientList = new List(6);
			loadPatient();
			add(patientList);
			
			//When a list item is selected populate the text fields
			patientList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM patient");
						while (rs.next()) 
						{
							if (rs.getString("patid").equals(patientList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							patidText.setText(rs.getString("patid"));
							patNameText.setText(rs.getString("patName"));
							patMailText.setText(rs.getString("patMail"));
							patMobilenoText.setText(rs.getString("patMobileno"));
							patAddressText.setText(rs.getString("patAddress"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			//Handle Update Menu Button
			modify = new Button("Update Patient");
			modify.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("UPDATE patient  SET patid='" + patidText.getText() + "',patMail='" + patMailText.getText() + "',patMobileno='" + patMobilenoText.getText() + "',patAddress='" + patAddressText.getText()+ "' WHERE patid = '" + patientList.getSelectedItem() + "' ");
						errorText.append("\nUpdated " + i + " rows successfully");
						patientList.removeAll();
						loadPatient();
					} 
					catch (SQLException insertException) 
					{
						displaySQLErrors(insertException);
					}
				}
			});
			
			patidText = new TextField(15);
			patidText.setEditable(false);
			patNameText = new TextField(15);
			patNameText.setEditable(false);
			patMailText = new TextField(15);
			patMailText.setEditable(false);
			patMobilenoText = new TextField(15);
			patMobilenoText.setEditable(false);
			patAddressText = new TextField(15);
			patAddressText.setEditable(false);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Patient ID:"));
			first.add(patidText);
			first.add(new Label("Patient Name:"));
			first.add(patNameText);
			first.add(new Label("Patient Email:"));
			first.add(patMailText);
			first.add(new Label("Patient Mobileno:"));
			first.add(patMobilenoText);
			first.add(new Label("Patient Address:"));
			first.add(patAddressText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			//second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			
			add(second);
			add(third);
		    
			//setTitle("Update ....");
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void viewDonorGUI() 
		{	
			removeAll();
			donorList = new List(6);
			loadDonor();
			add(donorList);
			
			//When a list item is selected populate the text fields
			donorList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM donor");
						while (rs.next()) 
						{
							if (rs.getString("donorid").equals(donorList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							donoridText.setText(rs.getString("donorid"));
							donorNameText.setText(rs.getString("donorName"));
							donorMobilenoText.setText(rs.getString("donorMobileno"));
							donorBloodgrpText.setText(rs.getString("donorBloodgrp"));
							donorAddressText.setText(rs.getString("donorAddress"));
							
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			//Handle Update Menu Button
			modify = new Button("Update Donor");
			modify.addActionListener(new ActionListener()
			{
				public void actionPerformed(ActionEvent e) 
				{
					try 
					{
						Statement statement = connection.createStatement();
						int i = statement.executeUpdate("UPDATE donor  SET donorid='" + donoridText.getText() + "',donorMobileno='" + donorMobilenoText.getText() + "',donorAddress='" + donorAddressText.getText()+ "' WHERE donorid = '" + donorList.getSelectedItem() + "' ");
						errorText.append("\nUpdated " + i + " rows successfully");
						donorList.removeAll();
						loadDonor();
					} 
					catch (SQLException insertException) 
					{
						displaySQLErrors(insertException);
					}
				}
			});
			
			donoridText = new TextField(15);
			donoridText.setEditable(false);
			donorNameText = new TextField(15);
			donorNameText.setEditable(false);
			donorMobilenoText = new TextField(15);
			donorMobilenoText.setEditable(false);
			donorBloodgrpText = new TextField(15);
			donorBloodgrpText.setEditable(false);
			donorAddressText = new TextField(15);
			donorAddressText.setEditable(false);
			

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(5, 2));
			first.add(new Label("Donor ID:"));
			first.add(donoridText);
			first.add(new Label("Donor Name:"));
			first.add(donorNameText);
			first.add(new Label("Donor Mobileno:"));
			first.add(donorMobilenoText);
			first.add(new Label("Donor Bloodgrp:"));
			first.add(donorBloodgrpText);
			first.add(new Label("Donor Address:"));
			first.add(donorAddressText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			//second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    
			
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		
		public void viewICUbedsGUI() 
		{	
			removeAll();
			ICUbedsList = new List(6);
			loadICUbeds();
			add(ICUbedsList);
			
			//When a list item is selected populate the text fields
			ICUbedsList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM ICUbeds");
						while (rs.next()) 
						{
							if (rs.getString("bedid").equals(ICUbedsList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							bedidText.setText(rs.getString("bedid"));
							HospitalNameText.setText(rs.getString("HospitalName"));
							placeText.setText(rs.getString("place"));
							bedtypeText.setText(rs.getString("bedtype"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			
			bedidText = new TextField(15);
			bedidText.setEditable(false);
			HospitalNameText = new TextField(15);
			HospitalNameText.setEditable(false);
			placeText = new TextField(15);
			placeText.setEditable(false);
			bedtypeText = new TextField(15);
			bedtypeText.setEditable(false);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(4, 2));
			first.add(new Label("Bed ID:"));
			first.add(bedidText);
			first.add(new Label("Hospital Name:"));
			first.add(HospitalNameText);
			first.add(new Label("Place:"));
			first.add(placeText);
			first.add(new Label("Bed Type:"));
			first.add(bedtypeText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			//second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			add(second);
			add(third);
		    
			
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void viewRemedesivirsGUI() 
		{	
			removeAll();
			remedesivirsList = new List(6);
			loadRemedesivirs();
			add(remedesivirsList);
			
			//When a list item is selected populate the text fields
			remedesivirsList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM remedesivirs");
						while (rs.next()) 
						{
							if (rs.getString("remid").equals(remedesivirsList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							remidText.setText(rs.getString("remid"));
							availableRemText.setText(rs.getString("availableRem"));
							remPlaceText.setText(rs.getString("remPlace"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			
			remidText = new TextField(20);
			remidText.setEditable(false);
			availableRemText = new TextField(20);
			availableRemText.setEditable(false);
			remPlaceText = new TextField(20);
			remPlaceText.setEditable(false);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Remedesivir ID:"));
			first.add(remidText);
			first.add(new Label("Available Remedesivirs:"));
			first.add(availableRemText);
			first.add(new Label("Remedesivir Place:"));
			first.add(remPlaceText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			//second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			
			add(second);
			add(third);
		    
			//setTitle("Update ....");
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		public void viewPlasmaGUI() 
		{	
			removeAll();
			plasmaList = new List(6);
			loadPlasma();
			add(plasmaList);
			
			//When a list item is selected populate the text fields
			plasmaList.addItemListener(new ItemListener()
			{
				public void itemStateChanged(ItemEvent e) 
				{
					try 
					{
						rs = statement.executeQuery("SELECT * FROM plasma");
						while (rs.next()) 
						{
							if (rs.getString("plasmaid").equals(plasmaList.getSelectedItem()))
							break;
						}
						if (!rs.isAfterLast()) 
						{
							plasmaidText.setText(rs.getString("plasmaid"));
							plasmagrpText.setText(rs.getString("plasmagrp"));
							plasmaplaceText.setText(rs.getString("plasmaplace"));
						}
					} 
					catch (SQLException selectException) 
					{
						displaySQLErrors(selectException);
					}
				}
			});	    
			
			plasmaidText = new TextField(15);
			plasmaidText.setEditable(false);
			plasmagrpText = new TextField(15);
			plasmagrpText.setEditable(false);
			plasmaplaceText = new TextField(15);
			plasmaplaceText.setEditable(false);

			errorText = new TextArea(10, 40);
			errorText.setEditable(false);

			Panel first = new Panel();
			first.setLayout(new GridLayout(3, 2));
			first.add(new Label("Plasma ID:"));
			first.add(plasmaidText);
			first.add(new Label("Plasma/Blood Group:"));
			first.add(plasmagrpText);
			first.add(new Label("Plasma Place:"));
			first.add(plasmaplaceText);
			
			Panel second = new Panel(new GridLayout(4, 1));
			//second.add(modify);
			
			Panel third = new Panel();
			third.add(errorText);
			
			add(first);
			
			add(second);
			add(third);
		    
			//setTitle("Update ....");
			//setSize(500, 600);
			setLayout(new FlowLayout());
			setVisible(true);
			
		}
		
		
		
		public void displaySQLErrors(SQLException e) 
		{
			errorText.append("\nSQLException: " + e.getMessage() + "\n");
			errorText.append("SQLState:     " + e.getSQLState() + "\n");
			errorText.append("VendorError:  " + e.getErrorCode() + "\n");
		}

     	public static void main(String[] args) {
			InsertTables it = new InsertTables();
			it.addWindowListener(new WindowAdapter(){
			  public void windowClosing(WindowEvent e) 
			  {
				System.exit(0);
			  }
			});
			it.buildFrame();
		}
	}

		
		
		